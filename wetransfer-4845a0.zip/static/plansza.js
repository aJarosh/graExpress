class Plansza {
    constructor() {
    }
    gra() {
        $.ajax({
            url: "/gra",
            data: {
                action: "gra"
            },
            type: "POST",
            success: function (data) {
                console.log(data)
                if (data == "pierwszy") {
                    content.kwadraciki1()
                    content.pole_gry()
                    content.bialekule()
                    content.player = "pierwszy"

                }
                else {
                    content.kwadraciki2()
                    content.pole_gry()
                    content.szarekule()
                    var int = setInterval(() => {
                        console.log("sprawdzenie")
                        plansza.sprawdzenie(int)
                    }, 1000);
                    content.player = "drugi"
                    var int1 = setInterval(() => {
                        console.log("zapytanie o koniec")
                        plansza.zapytania_drugi()
                    }, 1000);
                }
            },
            error: function (xhr, status, error) {
                console.log(xhr);
            },
        });
    }
    wysylanieKolorow(kolory) {
        console.log("Wysyłanie kolorów AJAX")
        console.log(kolory)
        $.ajax({
            url: "/wysylanieKolorow",
            data: {
                kolory: kolory
            },
            type: "POST",
            success: function (data) {
                // console.log(data)
                this.zmiana != this.zmiana
                content.zmiana_gracza(this.zmiana)
            },
            error: function (xhr, status, error) {
                console.log(xhr);
            },
        })
    }

    sprawdzenie(int) {
        $.ajax({
            url: "/sprawdzenie",
            data: {
                spr: "Czy użytkownik jest gotowy?"
            },
            type: "POST",
            success: function (data) {
                if (data == "Pzegrana") {
                    window.alert("Pzegrana!")
                }
                console.log(data)
                data = data.split("/")
                if (data[0] == "Możesz grać") {
                    window.clearInterval(int)
                    console.log(data[1])
                    content.nastepneKule(data[1])
                    this.zmiana = false
                    content.zmiana_gracza(this.zmiana)
                }
            },
            error: function (xhr, status, error) {
                console.log(xhr);
            },
        })
    }
    czekaj_zmiana(int, player) {
        $.ajax({
            url: "/czekaj",
            data: {
                player: player
            },
            type: "POST",
            success: function (data) {
                if (data == "Przegrana") {
                    let h1 = $("<h1>")

                    h1.append("PRZEGRANA")
                    $("#root").append(h1)
                }
                else if (data == "Wygrana") {
                    let h1 = $("<h1>")

                    h1.append("WYGRANA")
                    $("#root").append(h1)
                }
                if (data.split("/")[0] == "Możesz grać") {
                    window.clearInterval(int)
                    content.nastepneKule(data.split("/")[1])
                    // console.log("zakańcza")
                    content.koloroweKule(data.split("/")[1], JSON.parse(data.split("/")[2]))
                    // console.log("bb");
                }
            },
            error: function (xhr, status, error) {
                console.log(xhr);
            },
        })
    }
    zapytania_drugi() {
        $.ajax({
            url: "/zapytania_drugi",
            data: {
                player: "drugi"
            },
            type: "POST",
            success: function (data) {
                if (data == "Przegrana") {
                    let h1 = $("<h1>")

                    h1.append("PRZEGRANA")
                    $("#root").append(h1)
                }
                else if (data == "Wygrana") {
                    let h1 = $("<h1>")

                    h1.append("WYGRANA")
                    $("#root").append(h1)
                }
            },
            error: function (xhr, status, error) {
                console.log(xhr);
            },
        })
    }
}


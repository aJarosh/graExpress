var start
var plansza
var content
$(document).ready(function () {
    start = new Start()
    plansza = new Plansza()
    content = new Content()
})